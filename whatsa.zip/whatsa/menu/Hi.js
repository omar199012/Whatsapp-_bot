import fs from 'fs-extra';
import CrateDatabase from '../module/CrateDatabase.js';

export default async function Hi(from, pushname, body, e) {

    if (body === 'hi' || body === 'Hi' || body === 'خدمة' || body === 'خدمه' || body === 'السلام عليكم' || body === 'السلام عليكم ورحمة الله وبركاته' || body === '#' || body === 'الو' || body === 'سلام' || body === 'مساء الخير' || body === 'صباح الخير' || body === 'كيفك' || body === 'هلا' || body === 'هلو' || body === 'البوت الإسلامي' || body === 'البوت' || body === 'اسلامي'){

        await CrateDatabase({ from: from, menu: 'main' });
        let message = `*السلام عليكم رحمة الله وبركاته* \n`
        message += `*${pushname} حياك الله* \n\n`
        message += '*▪️ لطلب مادة ما من المواد أدناه كل ما عليك إرسال رقم المادة باللغة العربية أو الإنجليزية* \n\n'
        message += '*مثال: 1* \n\n'
        message += '*1- ختمات القرآن الكريم.* \n'
        message += '*2- الباحث القرآني.* \n'
        message += '*3- الباحث الحديثي.* \n'
        message += '*4- بطاقات القرآن الكريم (صور مصممة وصوتية).* \n'
        message += '*5- صحيح البخاري (صور مصممة).* \n'
        message += '*6- حصن المسلم.* \n'
        message += '*7- التقويم الهجري.* \n'
        message += '*8- فيديوهات عشوائية(قرآن - مواعظ - أحاديث).* \n\n'
        
        message += '*نوصيكم أحبتنا وإخواننا في دعم مشروع البوت الإسلامي لظمان استمرارية العمل وعدم الإنقطاع إن شاء الله.*\n'
        message += '*يمكنكم الإنظمام لقناتنا على التلغرام والتواصل معنا (أهلاً وسهلاً بكم)*\n'
        message += '*https://t.me/QURAN_ISLAM_TV1*\n'
        message += '*يمكنكم الإنظمام لمجموعتنا الدعوية على الوتساب (أهلاً وسهلاً بكم)*\n'
        message += '*https://chat.whatsapp.com/EL5MNLM24gGE68P7NaRx2d*\n'
        await e.reply(message).catch(e => console.log(e));
    }
    
}
